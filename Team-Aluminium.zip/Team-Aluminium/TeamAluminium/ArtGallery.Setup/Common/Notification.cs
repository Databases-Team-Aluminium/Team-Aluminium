﻿namespace ArtGallery.Setup.Common
{
    public class Notification
    {
        public string Message { get; set; }
    }
}