﻿namespace ArtGallery.MongoDbModels.Common
{
    public enum ArtWorkStatus
    {
        ForExhibition = 0,
        ForSale = 1,
        Sold = 2,
        Private = 3
    }
}
