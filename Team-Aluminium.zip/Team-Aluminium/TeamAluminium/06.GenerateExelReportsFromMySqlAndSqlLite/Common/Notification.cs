﻿namespace GenerateExcelReportFromMySqlAndSqLite.Common
{
    public class Notification
    {
        public string Message { get; set; }
    }
}