﻿namespace CreateJsonReports.Common
{
    public interface IObserver
    {
        void Update(Notification notification);
    }
}