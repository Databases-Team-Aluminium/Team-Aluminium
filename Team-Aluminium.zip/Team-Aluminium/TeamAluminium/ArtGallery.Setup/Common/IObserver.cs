﻿namespace ArtGallery.Setup.Common
{
    public interface IObserver
    {
        void Update(Notification notification);
    }
}