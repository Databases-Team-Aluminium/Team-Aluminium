﻿namespace ArtGallery.MongoDbModels.Common
{
    public enum ArtStyle
    {
        Contemporary = 0,
        Gothic = 1,
        Eccentric = 2,
        Smooth = 3,
        Shique = 4
    }
}